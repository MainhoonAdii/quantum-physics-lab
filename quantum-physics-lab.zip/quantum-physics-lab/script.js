const canvas = document.getElementById("pattern");
const ctx = canvas.getContext("2d");
const mode = document.getElementById("mode");
const wavelength = document.getElementById("wavelength");
const waveValue = document.getElementById("waveValue");
const modeCaption = document.getElementById("modeCaption");

function drawPattern() {
  const w = canvas.width, h = canvas.height;
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#080e1b";
  ctx.fillRect(0, 0, w, h);

  // Screen glow and guide lines
  for (let x = 0; x < w; x += 40) {
    ctx.strokeStyle = "#ffffff0b";
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
  }
  const center = h / 2;
  const scale = Number(wavelength.value);
  const interference = mode.value === "wave";
  for (let x = 0; x < w; x++) {
    const normalized = (x - w / 2) / (w / 2);
    let intensity;
    if (interference) {
      const envelope = Math.exp(-normalized * normalized * 3.5);
      const fringes = Math.cos(normalized * 27 / scale);
      intensity = envelope * (0.12 + 0.88 * fringes * fringes);
    } else {
      // Smooth single-slit-like envelope when which-slit information is available.
      intensity = Math.exp(-normalized * normalized * (5.5 / scale));
    }
    const bandHeight = 7 + intensity * (h * 0.42);
    const alpha = Math.min(1, 0.12 + intensity * 0.88);
    ctx.fillStyle = `rgba(105,240,225,${alpha})`;
    ctx.fillRect(x, center - bandHeight / 2, 1.2, bandHeight);
  }
  ctx.strokeStyle = "#a99bff";
  ctx.setLineDash([5, 7]);
  ctx.beginPath(); ctx.moveTo(w / 2, 15); ctx.lineTo(w / 2, h - 15); ctx.stroke();
  ctx.setLineDash([]);
  ctx.fillStyle = "#a6b2ca";
  ctx.font = "14px monospace";
  ctx.fillText("SCREEN", 14, 24);
  modeCaption.textContent = interference ? "Illustrative interference pattern" : "Illustrative non-interference pattern";
  waveValue.textContent = ["short", "medium", "long"][scale - 1];
}
mode.addEventListener("change", drawPattern);
wavelength.addEventListener("input", drawPattern);
document.getElementById("reset").addEventListener("click", () => {
  mode.value = "wave";
  wavelength.value = "2";
  drawPattern();
});
drawPattern();