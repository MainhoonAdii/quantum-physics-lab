# ⚛ Quantum Physics Lab

An interactive, beginner-friendly website introducing core ideas in quantum physics. It includes short concept cards, a simplified double-slit pattern illustration, and a mini glossary.

## Features

- Responsive dark-themed landing page
- Introductory explanations of wave–particle duality, superposition, and uncertainty
- Interactive double-slit illustration with selectable detection setup and wavelength
- Quick historical facts and glossary
- No build tools or dependencies required

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a modern browser.

## Publish with GitHub Pages

1. Open the repository on GitHub.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select branch `main` and folder `/ (root)`, then click **Save**.
5. After deployment finishes, GitHub will show the published website URL in the Pages section.

## Project structure

- `index.html` — page structure and educational content
- `style.css` — visual design and responsive layout
- `script.js` — interactive canvas illustration
- `LICENSE` — MIT license
- `.gitignore` — common files to keep out of Git

## Scientific note

The double-slit visual is intentionally illustrative and qualitative. It is not a complete quantum-mechanical calculation and should not be used to predict experimental measurements. Quantum experiments depend on the physical setup and measurement procedure.

## Contributing

Suggestions, typo fixes, accessibility improvements, and scientifically careful explanations are welcome. Please keep explanations accessible and cite reliable references when adding scientific claims.
